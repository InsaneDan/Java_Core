package ru.geekbrains.java2.chat.client.models;

public enum ClientChatState {
    AUTHENTICATION,
    CHAT,
}
